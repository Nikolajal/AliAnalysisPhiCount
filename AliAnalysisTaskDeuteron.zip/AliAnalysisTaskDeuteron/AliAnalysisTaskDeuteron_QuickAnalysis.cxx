void
AliAnalysisTaskDeuteron_QuickAnalysis ( ) {
    TFile*  kInputFile  =   new TFile( "/Users/nikolajal/alice/AliAnalysisPhiCount/AliAnalysisTaskDeuteron/AnalysisResults.root" );
    //
    TTree*  kInputTree  =   (TTree*)(kInputFile->Get("PhiEfficiency_name"));
    //
    TH1F*   hRec = new TH1F( "hRec", "hRec", 100,0.,10. );
    TH1F*   hGen = new TH1F( "hGen", "hGen", 100,0.,10. );
    TH1F*   hEff = new TH1F( "hEff", "hEff", 100,0.,10. );
    //
    Int_t       nPhi;
    UChar_t       Selection[1024];
    Float_t     Px[1024], Py[1024], Pz[1024];
    //
    kInputTree->SetBranchAddress( "nPhi",       &nPhi );
    kInputTree->SetBranchAddress( "Selection",  &Selection );
    kInputTree->SetBranchAddress( "Px",         &Px );
    kInputTree->SetBranchAddress( "Py",         &Py );
    kInputTree->SetBranchAddress( "Pz",         &Pz );
    //
    for ( Int_t iEv = 0; iEv < kInputTree->GetEntries(); iEv++ ) {
        kInputTree->GetEvent(iEv);
        //
        TLorentzVector kDeuteron;
        for ( Int_t iPrt = 0; iPrt < nPhi; iPrt++ ) {
            kDeuteron.SetXYZM( Px[iPrt], Py[iPrt], Pz[iPrt], 1.875612942 );
            if ( (int)Selection[iPrt] >= 0  )   hGen->Fill( kDeuteron.Pt() );
            if ( (int)Selection[iPrt] == 11 )   hRec->Fill( kDeuteron.Pt() );
        }
        //
    }
    //
    TCanvas* c1 = new TCanvas();
    c1->Divide(3,1);
    //
    hEff->Divide( hRec, hGen, 1., 1., "b" );
    //
    c1->cd(1);
    hEff->Draw();
    c1->cd(2);
    hRec->Draw();
    c1->cd(3);
    hGen->Draw();
    //
}
